﻿namespace Exchangerate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.supportedCurrenciesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.latestRatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historicalRatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timeSeriesRatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.supportedCurrenciesToolStripMenuItem,
            this.latestRatesToolStripMenuItem,
            this.historicalRatesToolStripMenuItem,
            this.timeSeriesRatesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(554, 28);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // supportedCurrenciesToolStripMenuItem
            // 
            this.supportedCurrenciesToolStripMenuItem.Name = "supportedCurrenciesToolStripMenuItem";
            this.supportedCurrenciesToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.supportedCurrenciesToolStripMenuItem.Text = "Supported Currencies";
            this.supportedCurrenciesToolStripMenuItem.Click += new System.EventHandler(this.supportedCurrenciesToolStripMenuItem_Click);
            // 
            // latestRatesToolStripMenuItem
            // 
            this.latestRatesToolStripMenuItem.Name = "latestRatesToolStripMenuItem";
            this.latestRatesToolStripMenuItem.Size = new System.Drawing.Size(102, 24);
            this.latestRatesToolStripMenuItem.Text = "Latest Rates";
            this.latestRatesToolStripMenuItem.Click += new System.EventHandler(this.latestRatesToolStripMenuItem_Click);
            // 
            // historicalRatesToolStripMenuItem
            // 
            this.historicalRatesToolStripMenuItem.Name = "historicalRatesToolStripMenuItem";
            this.historicalRatesToolStripMenuItem.Size = new System.Drawing.Size(126, 24);
            this.historicalRatesToolStripMenuItem.Text = "Historical Rates";
            this.historicalRatesToolStripMenuItem.Click += new System.EventHandler(this.historicalRatesToolStripMenuItem_Click);
            // 
            // timeSeriesRatesToolStripMenuItem
            // 
            this.timeSeriesRatesToolStripMenuItem.Name = "timeSeriesRatesToolStripMenuItem";
            this.timeSeriesRatesToolStripMenuItem.Size = new System.Drawing.Size(141, 24);
            this.timeSeriesRatesToolStripMenuItem.Text = "Time-Series Rates";
            this.timeSeriesRatesToolStripMenuItem.Click += new System.EventHandler(this.timeSeriesRatesToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 69);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WORLD BUSINESS PRESS online";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem supportedCurrenciesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem latestRatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historicalRatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timeSeriesRatesToolStripMenuItem;
    }
}

